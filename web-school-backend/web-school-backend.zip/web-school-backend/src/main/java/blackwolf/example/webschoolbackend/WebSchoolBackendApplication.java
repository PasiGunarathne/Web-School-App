package blackwolf.example.webschoolbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebSchoolBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebSchoolBackendApplication.class, args);
	}

}
